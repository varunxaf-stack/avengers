import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform } from "motion/react";

const SPACE_BG = "https://images.unsplash.com/photo-1585083570023-3c099e7b464b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMGdhbGF4eSUyMG5lYnVsYSUyMHN0YXJzJTIwZGFyayUyMHB1cnBsZXxlbnwxfHx8fDE3NzQzNTIwMzV8MA&ixlib=rb-4.1.0&q=80&w=1920";

const LETTERS = "AVENGERS".split("");

function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let width = window.innerWidth;
    let height = window.innerHeight;

    canvas.width = width;
    canvas.height = height;

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };
    window.addEventListener("resize", resize);

    const count = Math.min(180, Math.floor((width * height) / 8000));
    const particles = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 1.8 + 0.3,
      speedX: (Math.random() - 0.5) * 0.25,
      speedY: (Math.random() - 0.5) * 0.25,
      opacity: Math.random() * 0.6 + 0.15,
      hue: Math.floor(Math.random() * 60), // 0-60 for red/gold range
    }));

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      particles.forEach((p, i) => {
        p.x += p.speedX;
        p.y += p.speedY;
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue + 30}, 90%, 80%, ${p.opacity})`;
        ctx.fill();

        // Connect nearby particles
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            const alpha = (1 - dist / 120) * 0.12;
            ctx.strokeStyle = `rgba(255, 180, 80, ${alpha})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      });

      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 z-10 pointer-events-none"
      style={{ opacity: 0.6 }}
    />
  );
}

export function HeroSection() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "40%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.08]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "60%"]);

  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouse = (e: MouseEvent) => {
      setMousePos({
        x: (e.clientX / window.innerWidth - 0.5) * 20,
        y: (e.clientY / window.innerHeight - 0.5) * 20,
      });
    };
    window.addEventListener("mousemove", handleMouse);
    return () => window.removeEventListener("mousemove", handleMouse);
  }, []);

  return (
    <section
      ref={ref}
      id="hero"
      className="relative w-full min-h-screen overflow-hidden flex items-center justify-center"
      style={{ background: "#050508" }}
    >
      {/* Parallax background */}
      <motion.div
        className="absolute inset-0 z-0"
        style={{ y: bgY, scale }}
      >
        <img
          src={SPACE_BG}
          alt="Space"
          className="w-full h-full object-cover"
          style={{ opacity: 0.5 }}
        />
        <div className="absolute inset-0" style={{
          background: "radial-gradient(ellipse at center, rgba(0,0,0,0.2) 0%, rgba(5,5,8,0.85) 70%)"
        }} />
      </motion.div>

      {/* Particles */}
      <ParticleCanvas />

      {/* Glow orbs */}
      <motion.div
        className="absolute z-5 rounded-full pointer-events-none"
        style={{
          width: 600,
          height: 600,
          background: "radial-gradient(circle, rgba(239,68,68,0.12) 0%, transparent 70%)",
          x: mousePos.x * 1.5,
          y: mousePos.y * 1.5,
          top: "20%",
          left: "10%",
          transition: "transform 0.1s",
        }}
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute z-5 rounded-full pointer-events-none"
        style={{
          width: 500,
          height: 500,
          background: "radial-gradient(circle, rgba(59,130,246,0.1) 0%, transparent 70%)",
          x: mousePos.x * -1,
          y: mousePos.y * -1,
          bottom: "10%",
          right: "5%",
          transition: "transform 0.1s",
        }}
        animate={{ scale: [1, 1.15, 1] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      />

      {/* Main content */}
      <motion.div
        className="relative z-20 flex flex-col items-center text-center px-6"
        style={{ y: textY, opacity }}
      >
        {/* Small label */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-6 flex items-center gap-3"
        >
          <div className="h-px w-16 bg-gradient-to-r from-transparent to-red-500" />
          <span
            className="text-red-400 tracking-[0.4em] uppercase text-xs"
            style={{ fontFamily: "Orbitron" }}
          >
            Marvel Cinematic Universe
          </span>
          <div className="h-px w-16 bg-gradient-to-l from-transparent to-red-500" />
        </motion.div>

        {/* THE */}
        <motion.p
          initial={{ opacity: 0, letterSpacing: "0.5em" }}
          animate={{ opacity: 1, letterSpacing: "0.8em" }}
          transition={{ duration: 1, delay: 0.4 }}
          className="text-gray-400 tracking-[0.8em] uppercase mb-2"
          style={{ fontFamily: "Rajdhani", fontWeight: 300, fontSize: "clamp(14px, 2vw, 20px)" }}
        >
          The
        </motion.p>

        {/* AVENGERS - letters assemble */}
        <div
          className="flex items-center justify-center overflow-visible"
          style={{ perspective: "800px" }}
        >
          {LETTERS.map((letter, i) => (
            <motion.span
              key={i}
              initial={{
                opacity: 0,
                y: i % 2 === 0 ? -120 : 120,
                rotateX: i % 2 === 0 ? -90 : 90,
                z: -200,
              }}
              animate={{
                opacity: 1,
                y: 0,
                rotateX: 0,
                z: 0,
              }}
              transition={{
                duration: 0.9,
                delay: 0.6 + i * 0.08,
                ease: [0.23, 1, 0.32, 1],
              }}
              style={{
                fontFamily: "Orbitron",
                fontWeight: 900,
                fontSize: "clamp(48px, 10vw, 130px)",
                lineHeight: 1,
                display: "inline-block",
                transformStyle: "preserve-3d",
                background: "linear-gradient(180deg, #ffffff 0%, #c0c0c0 40%, #6b7280 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                textShadow: "none",
                filter: "drop-shadow(0 0 30px rgba(239,68,68,0.4))",
                letterSpacing: "-0.02em",
              }}
            >
              {letter}
            </motion.span>
          ))}
        </div>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.4 }}
          className="mt-6 text-gray-400 max-w-lg"
          style={{
            fontFamily: "Rajdhani",
            fontWeight: 300,
            fontSize: "clamp(14px, 2vw, 18px)",
            letterSpacing: "0.15em",
          }}
        >
          Earth's Mightiest Heroes. When the world needs saving, they answer the call.
        </motion.p>

        {/* Stats row */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.8 }}
          className="flex items-center gap-8 mt-10"
        >
          {[["6", "Heroes"], ["10+", "Films"], ["23+", "Victories"]].map(([num, label]) => (
            <div key={label} className="text-center">
              <p
                className="text-white"
                style={{ fontFamily: "Orbitron", fontWeight: 700, fontSize: "clamp(20px, 3vw, 32px)" }}
              >
                {num}
              </p>
              <p
                className="text-gray-500 tracking-widest uppercase"
                style={{ fontFamily: "Rajdhani", fontSize: "11px" }}
              >
                {label}
              </p>
            </div>
          ))}
        </motion.div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 2 }}
          className="mt-10"
        >
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(239,68,68,0.5)" }}
            whileTap={{ scale: 0.97 }}
            className="px-8 py-3 rounded-sm uppercase tracking-widest text-white relative overflow-hidden group"
            style={{
              fontFamily: "Orbitron",
              fontSize: "12px",
              fontWeight: 600,
              border: "1px solid rgba(239,68,68,0.5)",
              background: "rgba(239,68,68,0.1)",
            }}
            onClick={() => {
              document.querySelector("#iron-man")?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            <span className="relative z-10">Meet the Heroes</span>
            <motion.div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
              style={{
                background: "linear-gradient(135deg, rgba(239,68,68,0.3), rgba(245,158,11,0.2))",
              }}
            />
          </motion.button>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.5 }}
          className="mt-14 flex flex-col items-center gap-2"
        >
          <span
            className="text-gray-600 tracking-widest uppercase"
            style={{ fontFamily: "Orbitron", fontSize: "9px" }}
          >
            Scroll
          </span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            className="w-px h-10 bg-gradient-to-b from-red-500 to-transparent"
          />
        </motion.div>
      </motion.div>

      {/* Bottom gradient fade */}
      <div
        className="absolute bottom-0 left-0 right-0 h-40 z-20 pointer-events-none"
        style={{ background: "linear-gradient(to top, #050508 0%, transparent 100%)" }}
      />
    </section>
  );
}
