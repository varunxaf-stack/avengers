import { useRef, useState } from "react";
import { motion, useInView } from "motion/react";
import type { Character } from "./CharacterSection";

function HeroCard({ character, index }: { character: Character; index: number }) {
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 60, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: [0.23, 1, 0.32, 1] }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="relative overflow-hidden rounded-xl cursor-pointer group"
      style={{ aspectRatio: "2/3" }}
    >
      {/* Image */}
      <motion.img
        src={character.image}
        alt={character.name}
        className="w-full h-full object-cover"
        animate={{ scale: hovered ? 1.08 : 1 }}
        transition={{ duration: 0.5 }}
      />

      {/* Gradient overlay */}
      <div
        className="absolute inset-0"
        style={{
          background: `linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.4) 40%, transparent 100%)`,
        }}
      />

      {/* Color overlay */}
      <motion.div
        className="absolute inset-0"
        animate={{ opacity: hovered ? 0.2 : 0 }}
        style={{ background: character.color }}
        transition={{ duration: 0.3 }}
      />

      {/* Glow border */}
      <motion.div
        className="absolute inset-0 rounded-xl pointer-events-none"
        animate={{
          boxShadow: hovered ? `inset 0 0 0 2px ${character.color}80, 0 0 30px ${character.color}50` : `inset 0 0 0 1px rgba(255,255,255,0.05)`,
        }}
        transition={{ duration: 0.3 }}
      />

      {/* Info */}
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <motion.div
          animate={{ y: hovered ? 0 : 8, opacity: hovered ? 1 : 0.7 }}
          transition={{ duration: 0.3 }}
        >
          <p
            className="text-gray-500 tracking-widest uppercase mb-0.5"
            style={{ fontFamily: "Orbitron", fontSize: "8px" }}
          >
            {character.alias}
          </p>
          <p
            className="text-white"
            style={{ fontFamily: "Orbitron", fontWeight: 700, fontSize: "14px" }}
          >
            {character.name}
          </p>
          <motion.div
            className="mt-1.5 h-[2px] rounded-full"
            animate={{ width: hovered ? "100%" : "24px" }}
            transition={{ duration: 0.4 }}
            style={{ background: `linear-gradient(90deg, ${character.color}, ${character.accentColor})` }}
          />
        </motion.div>

        {/* Abilities on hover */}
        <motion.div
          animate={{ height: hovered ? "auto" : 0, opacity: hovered ? 1 : 0 }}
          className="overflow-hidden mt-3"
        >
          <div className="flex flex-wrap gap-1">
            {character.abilities.slice(0, 3).map((a) => (
              <span
                key={a}
                className="px-2 py-0.5 rounded-sm"
                style={{
                  fontFamily: "Orbitron",
                  fontSize: "7px",
                  color: character.color,
                  border: `1px solid ${character.color}40`,
                  background: `${character.color}10`,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                }}
              >
                {a}
              </span>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Floating symbol on hover */}
      <motion.div
        className="absolute top-4 right-4"
        animate={{ opacity: hovered ? 1 : 0, scale: hovered ? 1 : 0.5 }}
        transition={{ duration: 0.3 }}
        style={{
          fontFamily: "Orbitron",
          fontWeight: 900,
          fontSize: "11px",
          color: character.color,
          letterSpacing: "0.15em",
          textTransform: "uppercase",
        }}
      >
        {character.symbol}
      </motion.div>
    </motion.div>
  );
}

export function AssembleSection({ characters }: { characters: Character[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      id="assemble"
      className="relative min-h-screen py-24 overflow-hidden"
      style={{ background: "#050508" }}
    >
      {/* Radial glow background */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 0%, rgba(239,68,68,0.12) 0%, rgba(59,130,246,0.08) 40%, transparent 70%)",
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <div ref={ref} className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="flex items-center justify-center gap-4 mb-4"
          >
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-red-500" />
            <span
              className="text-red-500 tracking-[0.4em] uppercase text-xs"
              style={{ fontFamily: "Orbitron" }}
            >
              Together as one
            </span>
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-red-500" />
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            style={{
              fontFamily: "Orbitron",
              fontWeight: 900,
              fontSize: "clamp(40px, 7vw, 90px)",
              lineHeight: 1,
              background: "linear-gradient(135deg, #ef4444 0%, #f59e0b 50%, #3b82f6 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              filter: "drop-shadow(0 0 40px rgba(239,68,68,0.4))",
            }}
          >
            Avengers
          </motion.h2>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.15 }}
            style={{
              fontFamily: "Orbitron",
              fontWeight: 900,
              fontSize: "clamp(40px, 7vw, 90px)",
              lineHeight: 1,
              background: "linear-gradient(135deg, #3b82f6 0%, #7c3aed 50%, #16a34a 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Assemble
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.25 }}
            className="text-gray-500 mt-6 max-w-xl mx-auto"
            style={{ fontFamily: "Rajdhani", fontWeight: 400, fontSize: "16px", lineHeight: 1.7 }}
          >
            Six extraordinary individuals. Brought together by fate. United by purpose. Earth's last line of defense.
          </motion.p>
        </div>

        {/* Characters grid */}
        {inView && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {characters.map((char, i) => (
              <HeroCard key={char.id} character={char} index={i} />
            ))}
          </div>
        )}

        {/* Bottom motto */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8 }}
          className="text-center mt-20"
        >
          <div className="flex items-center justify-center gap-6 mb-6">
            {["#ef4444", "#3b82f6", "#1d4ed8", "#16a34a", "#dc2626", "#7c3aed"].map((color, i) => (
              <motion.div
                key={color}
                className="w-2 h-2 rounded-full"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.4, 1, 0.4],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.3,
                  ease: "easeInOut",
                }}
                style={{ background: color }}
              />
            ))}
          </div>

          <p
            className="text-gray-700 tracking-[0.5em] uppercase"
            style={{ fontFamily: "Orbitron", fontSize: "10px" }}
          >
            Whatever it takes
          </p>

          {/* Avengers logo at bottom */}
          <motion.div
            className="mt-8 flex justify-center"
            animate={{ opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
            <svg viewBox="0 0 60 60" className="w-12 h-12">
              <polygon
                points="30,3 57,50 3,50"
                fill="none"
                stroke="url(#bottomGrad)"
                strokeWidth="2"
              />
              <text
                x="30"
                y="42"
                textAnchor="middle"
                fill="url(#bottomGrad)"
                fontSize="24"
                fontFamily="Orbitron"
                fontWeight="900"
              >
                A
              </text>
              <defs>
                <linearGradient id="bottomGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ef4444" />
                  <stop offset="100%" stopColor="#f59e0b" />
                </linearGradient>
              </defs>
            </svg>
          </motion.div>
        </motion.div>
      </div>

      {/* Top fade */}
      <div className="absolute top-0 left-0 right-0 h-24 pointer-events-none"
        style={{ background: "linear-gradient(to bottom, #050508 0%, transparent 100%)" }} />
    </section>
  );
}
