import { useEffect, useState } from "react";
import { motion, useScroll, useSpring } from "motion/react";

const NAV_LINKS = [
  { label: "Iron Man", href: "#iron-man", color: "#ef4444" },
  { label: "Thor", href: "#thor", color: "#3b82f6" },
  { label: "Cap", href: "#captain-america", color: "#1d4ed8" },
  { label: "Hulk", href: "#hulk", color: "#16a34a" },
  { label: "Black Widow", href: "#black-widow", color: "#dc2626" },
  { label: "Hawkeye", href: "#hawkeye", color: "#7c3aed" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState("");
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      {/* Scroll progress bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-[3px] z-[100] origin-left"
        style={{
          scaleX,
          background: "linear-gradient(90deg, #ef4444, #f59e0b, #3b82f6, #16a34a)",
        }}
      />

      <motion.nav
        className="fixed top-[3px] left-0 right-0 z-50 flex items-center justify-between px-6 py-3"
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        style={{
          background: scrolled
            ? "rgba(0,0,0,0.85)"
            : "transparent",
          backdropFilter: scrolled ? "blur(16px)" : "none",
          borderBottom: scrolled ? "1px solid rgba(255,255,255,0.07)" : "none",
          transition: "background 0.4s ease, backdrop-filter 0.4s ease",
        }}
      >
        {/* Logo */}
        <a
          href="#hero"
          className="flex items-center gap-2 group"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <div className="relative w-9 h-9">
            <svg viewBox="0 0 40 40" className="w-full h-full">
              <polygon
                points="20,2 38,32 2,32"
                fill="none"
                stroke="url(#aGrad)"
                strokeWidth="2.5"
                className="group-hover:opacity-80 transition-opacity"
              />
              <text
                x="20"
                y="27"
                textAnchor="middle"
                fill="url(#aGrad)"
                fontSize="16"
                fontFamily="Orbitron"
                fontWeight="900"
              >
                A
              </text>
              <defs>
                <linearGradient id="aGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ef4444" />
                  <stop offset="100%" stopColor="#f59e0b" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <span
            className="hidden sm:block text-white tracking-widest uppercase"
            style={{ fontFamily: "Orbitron", fontSize: "13px", fontWeight: 700 }}
          >
            Avengers
          </span>
        </a>

        {/* Nav links */}
        <div className="hidden md:flex items-center gap-1">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                const el = document.querySelector(link.href);
                el?.scrollIntoView({ behavior: "smooth" });
              }}
              className="px-3 py-1.5 rounded text-xs tracking-widest uppercase transition-all duration-300 text-gray-400 hover:text-white relative group"
              style={{ fontFamily: "Orbitron" }}
            >
              {link.label}
              <span
                className="absolute bottom-0 left-0 right-0 h-[2px] scale-x-0 group-hover:scale-x-100 transition-transform origin-left rounded-full"
                style={{ background: link.color }}
              />
            </a>
          ))}
        </div>

        {/* CTA */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.97 }}
          className="px-4 py-2 rounded text-xs tracking-widest uppercase text-black font-bold"
          style={{
            fontFamily: "Orbitron",
            background: "linear-gradient(135deg, #ef4444, #f59e0b)",
          }}
          onClick={() => {
            document.querySelector("#assemble")?.scrollIntoView({ behavior: "smooth" });
          }}
        >
          Assemble
        </motion.button>
      </motion.nav>
    </>
  );
}
