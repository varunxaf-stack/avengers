import { useRef } from "react";
import { motion, useInView } from "motion/react";

const events = [
  {
    year: "2008",
    title: "Birth of Iron Man",
    description: "Tony Stark builds the first Iron Man suit in a cave. A genius is reborn as a hero.",
    color: "#ef4444",
  },
  {
    year: "2011",
    title: "Thor's Banishment",
    description: "Thor is cast down from Asgard to Earth, where he must prove himself worthy.",
    color: "#3b82f6",
  },
  {
    year: "2012",
    title: "Battle of New York",
    description: "The Avengers assemble for the first time to stop Loki and the Chitauri invasion.",
    color: "#f59e0b",
  },
  {
    year: "2014",
    title: "The Winter Soldier",
    description: "Captain America uncovers HYDRA's infiltration of S.H.I.E.L.D. and faces a ghost from his past.",
    color: "#1d4ed8",
  },
  {
    year: "2015",
    title: "Age of Ultron",
    description: "Tony Stark's AI creation Ultron turns rogue, forcing the Avengers to fight their own creation.",
    color: "#ef4444",
  },
  {
    year: "2016",
    title: "Civil War",
    description: "The Avengers fracture over the Sokovia Accords. Teammates become adversaries.",
    color: "#dc2626",
  },
  {
    year: "2018",
    title: "Infinity War",
    description: "Thanos collects all six Infinity Stones. The snap erases half of all life.",
    color: "#7c3aed",
  },
  {
    year: "2023",
    title: "Endgame",
    description: "The remaining Avengers execute a time heist and make the ultimate sacrifice to undo the snap.",
    color: "#f59e0b",
  },
];

function TimelineEvent({ event, index }: { event: typeof events[0]; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const isLeft = index % 2 === 0;

  return (
    <div ref={ref} className={`relative flex items-center gap-0 ${isLeft ? "flex-row" : "flex-row-reverse"}`}>
      {/* Content */}
      <motion.div
        initial={{ opacity: 0, x: isLeft ? -50 : 50 }}
        animate={inView ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
        className={`w-5/12 ${isLeft ? "text-right pr-8" : "text-left pl-8"}`}
      >
        <span
          className="block mb-1"
          style={{
            fontFamily: "Orbitron",
            fontWeight: 700,
            fontSize: "13px",
            color: event.color,
            letterSpacing: "0.2em",
          }}
        >
          {event.year}
        </span>
        <h3
          className="text-white mb-2"
          style={{
            fontFamily: "Orbitron",
            fontWeight: 700,
            fontSize: "clamp(14px, 1.5vw, 18px)",
          }}
        >
          {event.title}
        </h3>
        <p
          className="text-gray-500"
          style={{ fontFamily: "Rajdhani", fontWeight: 400, fontSize: "clamp(13px, 1.2vw, 15px)", lineHeight: 1.6 }}
        >
          {event.description}
        </p>
      </motion.div>

      {/* Center dot */}
      <div className="w-2/12 flex flex-col items-center">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={inView ? { scale: 1, opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="relative z-10 w-4 h-4 rounded-full flex items-center justify-center"
          style={{ background: event.color, boxShadow: `0 0 20px ${event.color}80` }}
        >
          <div className="w-2 h-2 rounded-full bg-black" />
        </motion.div>
      </div>

      {/* Empty space */}
      <div className="w-5/12" />
    </div>
  );
}

export function TimelineSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });

  return (
    <section
      className="relative py-24 overflow-hidden"
      style={{ background: "#050508" }}
    >
      {/* Background decoration */}
      <div
        className="absolute inset-0"
        style={{
          background: "radial-gradient(ellipse at center, rgba(245,158,11,0.05) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-6">
        {/* Header */}
        <div ref={ref} className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="flex items-center justify-center gap-4 mb-4"
          >
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-yellow-500" />
            <span
              className="text-yellow-500 tracking-[0.4em] uppercase text-xs"
              style={{ fontFamily: "Orbitron" }}
            >
              The Story So Far
            </span>
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-yellow-500" />
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            style={{
              fontFamily: "Orbitron",
              fontWeight: 900,
              fontSize: "clamp(32px, 5vw, 56px)",
              background: "linear-gradient(135deg, #ffffff, #9ca3af)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            MCU Timeline
          </motion.h2>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Center vertical line */}
          <div
            className="absolute left-1/2 top-0 bottom-0 w-px -translate-x-1/2"
            style={{ background: "linear-gradient(to bottom, transparent, rgba(255,255,255,0.1), transparent)" }}
          />

          <div className="space-y-12">
            {events.map((event, i) => (
              <TimelineEvent key={event.year} event={event} index={i} />
            ))}
          </div>
        </div>
      </div>

      {/* Section fades */}
      <div className="absolute top-0 left-0 right-0 h-24 pointer-events-none"
        style={{ background: "linear-gradient(to bottom, #050508 0%, transparent 100%)" }} />
      <div className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none"
        style={{ background: "linear-gradient(to top, #050508 0%, transparent 100%)" }} />
    </section>
  );
}
