import { useRef, useState } from "react";
import {
  motion,
  useScroll,
  useTransform,
  useMotionValue,
  useSpring,
  useInView,
} from "motion/react";

export interface Character {
  id: string;
  name: string;
  alias: string;
  title: string;
  tagline: string;
  description: string;
  color: string;
  accentColor: string;
  bgGradient: string;
  image: string;
  bgImage: string;
  abilities: string[];
  stats: { label: string; value: number }[];
  symbol: string;
}

function StatBar({ label, value, color, delay }: { label: string; value: number; color: string; delay: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });

  return (
    <div ref={ref} className="space-y-1">
      <div className="flex justify-between items-center">
        <span
          className="text-gray-400 tracking-widest uppercase"
          style={{ fontFamily: "Rajdhani", fontSize: "11px" }}
        >
          {label}
        </span>
        <span
          className="text-white"
          style={{ fontFamily: "Orbitron", fontSize: "11px", fontWeight: 700 }}
        >
          {value}
        </span>
      </div>
      <div className="h-[3px] bg-white/10 rounded-full overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          initial={{ width: 0 }}
          animate={inView ? { width: `${value}%` } : { width: 0 }}
          transition={{ duration: 1.2, delay, ease: "easeOut" }}
          style={{ background: `linear-gradient(90deg, ${color}, ${color}88)` }}
        />
      </div>
    </div>
  );
}

function TiltCard({ image, name, color, accentColor, symbol }: {
  image: string;
  name: string;
  color: string;
  accentColor: string;
  symbol: string;
}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const rotateX = useMotionValue(0);
  const rotateY = useMotionValue(0);
  const springX = useSpring(rotateX, { stiffness: 200, damping: 25 });
  const springY = useSpring(rotateY, { stiffness: 200, damping: 25 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = cardRef.current?.getBoundingClientRect();
    if (!rect) return;
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const rotX = ((e.clientY - centerY) / (rect.height / 2)) * -12;
    const rotY = ((e.clientX - centerX) / (rect.width / 2)) * 12;
    rotateX.set(rotX);
    rotateY.set(rotY);
  };

  const handleMouseLeave = () => {
    rotateX.set(0);
    rotateY.set(0);
    setIsHovered(false);
  };

  return (
    <div style={{ perspective: "1200px" }} className="w-full max-w-sm mx-auto">
      <motion.div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={handleMouseLeave}
        style={{
          rotateX: springX,
          rotateY: springY,
          transformStyle: "preserve-3d",
        }}
        animate={{
          y: [0, -12, 0],
        }}
        transition={{
          y: { duration: 4, repeat: Infinity, ease: "easeInOut" },
        }}
        className="relative rounded-2xl overflow-hidden cursor-pointer"
      >
        {/* Card background */}
        <div
          className="absolute inset-0"
          style={{
            background: `linear-gradient(145deg, rgba(0,0,0,0.6), rgba(0,0,0,0.85))`,
            border: `1px solid ${color}40`,
          }}
        />

        {/* Glowing border */}
        <motion.div
          className="absolute inset-0 rounded-2xl pointer-events-none"
          animate={{
            boxShadow: isHovered
              ? `0 0 40px ${color}60, inset 0 0 30px ${color}20`
              : `0 0 20px ${color}30, inset 0 0 10px ${color}10`,
          }}
          transition={{ duration: 0.3 }}
        />

        {/* Hero image */}
        <div className="relative aspect-[3/4] overflow-hidden">
          <motion.img
            src={image}
            alt={name}
            className="w-full h-full object-cover"
            animate={{ scale: isHovered ? 1.05 : 1 }}
            transition={{ duration: 0.5 }}
          />
          {/* Image overlay gradient */}
          <div
            className="absolute inset-0"
            style={{
              background: `linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.2) 50%, transparent 100%)`,
            }}
          />
          {/* Color overlay */}
          <motion.div
            className="absolute inset-0"
            animate={{ opacity: isHovered ? 0.15 : 0.05 }}
            style={{ background: color }}
          />
        </div>

        {/* Card bottom info */}
        <div className="absolute bottom-0 left-0 right-0 p-5" style={{ transform: "translateZ(20px)" }}>
          <p
            className="text-white/50 tracking-widest uppercase mb-1"
            style={{ fontFamily: "Rajdhani", fontSize: "11px" }}
          >
            {symbol}
          </p>
          <p
            className="text-white"
            style={{ fontFamily: "Orbitron", fontWeight: 700, fontSize: "18px" }}
          >
            {name}
          </p>
          {/* Glowing underline */}
          <motion.div
            className="mt-2 h-[2px] rounded-full"
            animate={{ width: isHovered ? "100%" : "30%" }}
            transition={{ duration: 0.4 }}
            style={{ background: `linear-gradient(90deg, ${color}, ${accentColor})` }}
          />
        </div>

        {/* Glare effect + portrait badge */}
        <motion.div
          className="absolute inset-0 pointer-events-none rounded-2xl"
          style={{
            background: `radial-gradient(circle at ${50 + springY.get() * 2}% ${50 - springX.get() * 2}%, rgba(255,255,255,0.08) 0%, transparent 60%)`,
          }}
          animate={{ opacity: isHovered ? 1 : 0 }}
        >
          {/* Character portrait badge — top-right corner, revealed on hover */}
          <motion.div
            className="absolute top-3 right-3 overflow-hidden rounded-full"
            animate={{
              scale: isHovered ? 1 : 0.6,
              opacity: isHovered ? 1 : 0,
            }}
            transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1] }}
            style={{
              width: 64,
              height: 64,
              border: `2px solid ${color}`,
              boxShadow: `0 0 16px ${color}80`,
            }}
          >
            <img
              src={image}
              alt={name}
              className="w-full h-full object-cover"
              style={{ filter: "brightness(1.1) saturate(1.2)" }}
            />
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
}

export function CharacterSection({ character, index }: { character: Character; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const infoRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(infoRef, { once: true, margin: "-100px" });

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const bgY = useTransform(scrollYProgress, [0, 1], ["-10%", "10%"]);
  const cardX = useTransform(
    scrollYProgress,
    [0, 0.4, 0.6, 1],
    [index % 2 === 0 ? -80 : 80, 0, 0, index % 2 === 0 ? -40 : 40]
  );
  const cardOpacity = useTransform(scrollYProgress, [0.05, 0.25, 0.75, 0.95], [0, 1, 1, 0]);

  const isEven = index % 2 === 0;

  const containerVariants = {
    hidden: {},
    visible: {
      transition: { staggerChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, x: isEven ? 60 : -60 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.7, ease: [0.23, 1, 0.32, 1] } },
  };

  return (
    <section
      ref={ref}
      id={character.id}
      className="relative min-h-screen flex items-center overflow-hidden py-20"
      style={{ background: "#050508" }}
    >
      {/* Parallax background */}
      <motion.div className="absolute inset-0 z-0" style={{ y: bgY }}>
        <img
          src={character.bgImage}
          alt=""
          className="w-full h-full object-cover"
          style={{ opacity: 0.2, filter: "blur(2px)" }}
        />
        <div
          className="absolute inset-0"
          style={{
            background: `radial-gradient(ellipse at ${isEven ? "70%" : "30%"} 50%, ${character.color}15 0%, transparent 60%)`,
          }}
        />
      </motion.div>

      {/* Section gradient overlay */}
      <div
        className="absolute inset-0 z-1"
        style={{
          background: `linear-gradient(${isEven ? "to right" : "to left"}, rgba(5,5,8,0.98) 0%, rgba(5,5,8,0.7) 60%, rgba(5,5,8,0.4) 100%)`,
        }}
      />

      {/* Top/bottom fades */}
      <div className="absolute top-0 left-0 right-0 h-32 z-10 pointer-events-none"
        style={{ background: "linear-gradient(to bottom, #050508 0%, transparent 100%)" }} />
      <div className="absolute bottom-0 left-0 right-0 h-32 z-10 pointer-events-none"
        style={{ background: "linear-gradient(to top, #050508 0%, transparent 100%)" }} />

      {/* Decorative number */}
      <div
        className="absolute z-1 select-none pointer-events-none"
        style={{
          fontFamily: "Orbitron",
          fontWeight: 900,
          fontSize: "clamp(180px, 25vw, 300px)",
          color: `${character.color}08`,
          top: "50%",
          [isEven ? "right" : "left"]: "-2%",
          transform: "translateY(-50%)",
          lineHeight: 1,
        }}
      >
        0{index + 1}
      </div>

      {/* Main content */}
      <div className="relative z-20 w-full max-w-7xl mx-auto px-6 lg:px-12">
        <div
          className={`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center ${
            isEven ? "" : "lg:flex lg:flex-row-reverse"
          }`}
        >
          {/* 3D Card */}
          <motion.div
            style={{ x: cardX, opacity: cardOpacity }}
            className="w-full flex justify-center"
          >
            <TiltCard
              image={character.image}
              name={character.name}
              color={character.color}
              accentColor={character.accentColor}
              symbol={character.symbol}
            />
          </motion.div>

          {/* Character Info */}
          <motion.div
            ref={infoRef}
            variants={containerVariants}
            initial="hidden"
            animate={isInView ? "visible" : "hidden"}
            className="space-y-6"
          >
            {/* Index + alias */}
            <motion.div variants={itemVariants} className="flex items-center gap-3">
              <div
                className="h-px w-12"
                style={{ background: character.color }}
              />
              <span
                className="tracking-[0.3em] uppercase text-xs"
                style={{
                  fontFamily: "Rajdhani",
                  color: character.color,
                  fontWeight: 600,
                }}
              >
                {character.alias}
              </span>
            </motion.div>

            {/* Hero name */}
            <motion.h2
              variants={itemVariants}
              style={{
                fontFamily: "Orbitron",
                fontWeight: 900,
                fontSize: "clamp(36px, 5vw, 64px)",
                lineHeight: 1,
                background: `linear-gradient(135deg, #ffffff 30%, ${character.color} 100%)`,
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              {character.name}
            </motion.h2>

            {/* Title */}
            <motion.p
              variants={itemVariants}
              className="text-gray-400 tracking-widest uppercase"
              style={{ fontFamily: "Rajdhani", fontSize: "13px", fontWeight: 500 }}
            >
              {character.title}
            </motion.p>

            {/* Tagline */}
            <motion.blockquote
              variants={itemVariants}
              className="border-l-2 pl-4 italic text-white/80"
              style={{
                borderColor: character.color,
                fontFamily: "Rajdhani",
                fontWeight: 400,
                fontSize: "clamp(16px, 2vw, 20px)",
              }}
            >
              "{character.tagline}"
            </motion.blockquote>

            {/* Description */}
            <motion.p
              variants={itemVariants}
              className="text-gray-400 leading-relaxed"
              style={{ fontFamily: "Rajdhani", fontWeight: 400, fontSize: "clamp(14px, 1.5vw, 16px)" }}
            >
              {character.description}
            </motion.p>

            {/* Abilities */}
            <motion.div variants={itemVariants} className="flex flex-wrap gap-2">
              {character.abilities.map((ability) => (
                <span
                  key={ability}
                  className="px-3 py-1 rounded-sm text-xs tracking-widest uppercase"
                  style={{
                    fontFamily: "Orbitron",
                    border: `1px solid ${character.color}40`,
                    color: character.color,
                    background: `${character.color}10`,
                    fontSize: "9px",
                  }}
                >
                  {ability}
                </span>
              ))}
            </motion.div>

            {/* Stats */}
            <motion.div variants={itemVariants} className="space-y-3 pt-2">
              <p
                className="text-gray-600 tracking-widest uppercase mb-3"
                style={{ fontFamily: "Orbitron", fontSize: "9px" }}
              >
                Power Stats
              </p>
              {character.stats.map((stat, i) => (
                <StatBar
                  key={stat.label}
                  label={stat.label}
                  value={stat.value}
                  color={character.color}
                  delay={i * 0.15}
                />
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Side accent line */}
      <motion.div
        className="absolute left-0 top-0 bottom-0 w-[3px]"
        style={{
          background: `linear-gradient(to bottom, transparent, ${character.color}, transparent)`,
          scaleY: scrollYProgress,
          transformOrigin: "top",
        }}
      />
    </section>
  );
}