import "../styles/fonts.css";
import { Navbar } from "./components/Navbar";
import { HeroSection } from "./components/HeroSection";
import { CharacterSection } from "./components/CharacterSection";
import type { Character } from "./components/CharacterSection";
import { TimelineSection } from "./components/TimelineSection";
import { AssembleSection } from "./components/AssembleSection";

const CHARACTERS: Character[] = [
  {
    id: "iron-man",
    name: "Iron Man",
    alias: "Tony Stark",
    title: "The Invincible Iron Man",
    tagline: "I am Iron Man.",
    description:
      "A genius, billionaire, playboy, philanthropist — Tony Stark built a suit of armor in a cave with a box of scraps, and in doing so became something far greater than himself. His arc reactor, a symbol of resilience, powers not just his suit but the very heart of the Avengers initiative.",
    color: "#ef4444",
    accentColor: "#f59e0b",
    bgGradient: "from-red-950 to-black",
    image:
      "https://images.unsplash.com/photo-1764158302194-54b208aa7f2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpcm9uJTIwbWFuJTIwc3VpdCUyMGdsb3dpbmclMjByZWQlMjBnb2xkfGVufDF8fHx8MTc3NDM1MjAyN3ww&ixlib=rb-4.1.0&q=80&w=1080",
    bgImage:
      "https://images.unsplash.com/photo-1766016648768-254ede922ed5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwZnV0dXJpc3RpYyUyMGNpdHklMjBza3lsaW5lJTIwbmlnaHQlMjBuZW9ufGVufDF8fHx8MTc3NDM1MjA0MHww&ixlib=rb-4.1.0&q=80&w=1920",
    abilities: ["Genius Intellect", "Powered Armor", "Energy Repulsors", "Advanced Weaponry", "Flight"],
    stats: [
      { label: "Intelligence", value: 99 },
      { label: "Combat", value: 85 },
      { label: "Technology", value: 100 },
      { label: "Strength", value: 75 },
    ],
    symbol: "Mk. LXXXV",
  },
  {
    id: "thor",
    name: "Thor",
    alias: "Son of Odin",
    title: "The God of Thunder",
    tagline: "I choose to run towards my problems, not away from them.",
    description:
      "Banished from Asgard, Thor learned humility on Earth and became one of its greatest protectors. The Odinson wields the legendary Mjolnir, commands the power of lightning and thunder, and carries the burden of two worlds on his immortal shoulders.",
    color: "#3b82f6",
    accentColor: "#fbbf24",
    bgGradient: "from-blue-950 to-black",
    image:
      "https://images.unsplash.com/photo-1653562970495-d36d38608d08?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aG9yJTIwbGlnaHRuaW5nJTIwaGFtbWVyJTIwZHJhbWF0aWMlMjBza3l8ZW58MXx8fHwxNzc0MzUyMDMxfDA&ixlib=rb-4.1.0&q=80&w=1080",
    bgImage:
      "https://images.unsplash.com/photo-1653562970495-d36d38608d08?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aG9yJTIwbGlnaHRuaW5nJTIwaGFtbWVyJTIwZHJhbWF0aWMlMjBza3l8ZW58MXx8fHwxNzc0MzUyMDMxfDA&ixlib=rb-4.1.0&q=80&w=1920",
    abilities: ["Thunder & Lightning", "Mjolnir / Stormbreaker", "Superhuman Strength", "Asgardian Durability", "Flight"],
    stats: [
      { label: "Intelligence", value: 72 },
      { label: "Combat", value: 95 },
      { label: "Divinity", value: 98 },
      { label: "Strength", value: 97 },
    ],
    symbol: "Asgardian",
  },
  {
    id: "captain-america",
    name: "Captain America",
    alias: "Steve Rogers",
    title: "The First Avenger",
    tagline: "I can do this all day.",
    description:
      "A frail boy from Brooklyn transformed by the Super Soldier Serum into the world's first super soldier. Steve Rogers embodies the ideals of justice, honor, and sacrifice. Armed with his vibranium shield and unbreakable spirit, he stands as the moral compass of the Avengers.",
    color: "#2563eb",
    accentColor: "#ef4444",
    bgGradient: "from-blue-900 to-black",
    image:
      "https://images.unsplash.com/photo-1760780766638-99586575b13a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibHVlJTIwc3RhciUyMHBhdHJpb3QlMjBzb2xkaWVyJTIwd2FyJTIwaGVyb3xlbnwxfHx8fDE3NzQzNTIwMzl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    bgImage:
      "https://images.unsplash.com/photo-1760780766638-99586575b13a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibHVlJTIwc3RhciUyMHBhdHJpb3QlMjBzb2xkaWVyJTIwd2FyJTIwaGVyb3xlbnwxfHx8fDE3NzQzNTIwMzl8MA&ixlib=rb-4.1.0&q=80&w=1920",
    abilities: ["Super Soldier Serum", "Vibranium Shield", "Peak Human Physiology", "Tactical Genius", "Enhanced Healing"],
    stats: [
      { label: "Intelligence", value: 85 },
      { label: "Combat", value: 97 },
      { label: "Leadership", value: 100 },
      { label: "Strength", value: 88 },
    ],
    symbol: "1st Avenger",
  },
  {
    id: "hulk",
    name: "Hulk",
    alias: "Bruce Banner",
    title: "The Strongest Avenger",
    tagline: "That's my secret. I'm always angry.",
    description:
      "Dr. Bruce Banner, a brilliant gamma radiation scientist, was exposed to an immense dose that bonded him with an unstoppable force of rage. When anger consumes him, he transforms into the Incredible Hulk — an engine of pure destruction that grows stronger with every blow.",
    color: "#16a34a",
    accentColor: "#4ade80",
    bgGradient: "from-green-950 to-black",
    image:
      "https://images.unsplash.com/photo-1770783808113-890061b2ae10?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMG5hdHVyZSUyMHN0cm9uZyUyMHBvd2VyZnVsJTIwZW52aXJvbm1lbnR8ZW58MXx8fHwxNzc0MzUyMDM4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    bgImage:
      "https://images.unsplash.com/photo-1770783808113-890061b2ae10?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMG5hdHVyZSUyMHN0cm9uZyUyMHBvd2VyZnVsJTIwZW52aXJvbm1lbnR8ZW58MXx8fHwxNzc0MzUyMDM4fDA&ixlib=rb-4.1.0&q=80&w=1920",
    abilities: ["Limitless Strength", "Rage Amplification", "Gamma Regeneration", "Durability", "Thunderclap"],
    stats: [
      { label: "Intelligence", value: 90 },
      { label: "Combat", value: 88 },
      { label: "Rage Power", value: 100 },
      { label: "Strength", value: 100 },
    ],
    symbol: "Gamma Class",
  },
  {
    id: "black-widow",
    name: "Black Widow",
    alias: "Natasha Romanoff",
    title: "Master Spy & Assassin",
    tagline: "I've got red in my ledger. I'd like to wipe it out.",
    description:
      "Trained from childhood in the Red Room, Natasha Romanoff became the world's most dangerous spy. With no superhuman powers, she relies on unparalleled combat skill, cunning intellect, and nerves of steel. She balances her dark past by becoming one of S.H.I.E.L.D.'s most trusted agents.",
    color: "#dc2626",
    accentColor: "#6b7280",
    bgGradient: "from-gray-950 to-black",
    image:
      "https://images.unsplash.com/photo-1681549897627-e287d6e022d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibGFjayUyMHdpZG93JTIwc3B5JTIwYXNzYXNzaW4lMjBkYXJrJTIwbXlzdGVyaW91c3xlbnwxfHx8fDE3NzQzNTIwMzV8MA&ixlib=rb-4.1.0&q=80&w=1080",
    bgImage:
      "https://images.unsplash.com/photo-1681549897627-e287d6e022d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibGFjayUyMHdpZG93JTIwc3B5JTIwYXNzYXNzaW4lMjBkYXJrJTIwbXlzdGVyaW91c3xlbnwxfHx8fDE3NzQzNTIwMzV8MA&ixlib=rb-4.1.0&q=80&w=1920",
    abilities: ["Master Combatant", "Espionage", "Widow's Bite", "Acrobatics", "Multilingual"],
    stats: [
      { label: "Intelligence", value: 94 },
      { label: "Combat", value: 99 },
      { label: "Stealth", value: 98 },
      { label: "Strength", value: 65 },
    ],
    symbol: "Red Room",
  },
  {
    id: "hawkeye",
    name: "Hawkeye",
    alias: "Clint Barton",
    title: "World's Greatest Marksman",
    tagline: "The city is flying. We're fighting an army of robots. And I have a bow and arrow.",
    description:
      "Clint Barton needs no super serum, no arc reactor, no thunder. Armed with a quiver of specialized arrows and an unmatched eye, Hawkeye is proof that pure human skill and unwavering determination can stand shoulder to shoulder with gods and monsters.",
    color: "#7c3aed",
    accentColor: "#a78bfa",
    bgGradient: "from-purple-950 to-black",
    image:
      "https://images.unsplash.com/photo-1585083570023-3c099e7b464b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMGdhbGF4eSUyMG5lYnVsYSUyMHN0YXJzJTIwZGFyayUyMHB1cnBsZXxlbnwxfHx8fDE3NzQzNTIwMzV8MA&ixlib=rb-4.1.0&q=80&w=1080",
    bgImage:
      "https://images.unsplash.com/photo-1766016648768-254ede922ed5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwZnV0dXJpc3RpYyUyMGNpdHklMjBza3lsaW5lJTIwbmlnaHQlMjBuZW9ufGVufDF8fHx8MTc3NDM1MjA0MHww&ixlib=rb-4.1.0&q=80&w=1920",
    abilities: ["Master Archer", "Tactical Combat", "Custom Arrowheads", "Peak Athleticism", "S.H.I.E.L.D. Training"],
    stats: [
      { label: "Intelligence", value: 84 },
      { label: "Combat", value: 96 },
      { label: "Precision", value: 100 },
      { label: "Strength", value: 70 },
    ],
    symbol: "Ronin / Hawkeye",
  },
];

export default function App() {
  return (
    <div
      className="min-h-screen overflow-x-hidden"
      style={{ background: "#050508", color: "#ffffff" }}
    >
      <Navbar />
      <HeroSection />
      {CHARACTERS.map((character, i) => (
        <CharacterSection key={character.id} character={character} index={i} />
      ))}
      <TimelineSection />
      <AssembleSection characters={CHARACTERS} />

      {/* Footer */}
      <footer
        className="py-10 text-center border-t"
        style={{ borderColor: "rgba(255,255,255,0.05)", background: "#020204" }}
      >
        <p
          className="text-gray-700 tracking-widest uppercase"
          style={{ fontFamily: "Orbitron", fontSize: "9px" }}
        >
          © Marvel Studios · Avengers Portfolio · Fan-made Tribute
        </p>
        <p
          className="text-gray-800 mt-2"
          style={{ fontFamily: "Rajdhani", fontSize: "11px" }}
        >
          Whatever it takes.
        </p>
      </footer>
    </div>
  );
}
